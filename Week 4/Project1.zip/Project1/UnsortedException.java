package Project1;

public class UnsortedException extends Exception {
    public UnsortedException() {
        super("Array is not sorted!");
    }
}
